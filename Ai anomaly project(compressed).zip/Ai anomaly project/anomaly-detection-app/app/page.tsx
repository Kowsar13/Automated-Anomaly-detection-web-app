"use client"

import  from "../static/script"

export default function SyntheticV0PageForDeployment() {
  return < />
}