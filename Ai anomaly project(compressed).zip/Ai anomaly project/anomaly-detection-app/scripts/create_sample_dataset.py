import pandas as pd
import numpy as np
import os

def create_sample_dataset():
    """Create a sample network traffic dataset for testing"""
    
    # Set random seed for reproducibility
    np.random.seed(42)
    
    # Number of samples
    n_samples = 1000
    
    # Generate normal traffic data (80% of data)
    n_normal = int(n_samples * 0.8)
    
    normal_data = {
        'duration': np.random.exponential(1.0, n_normal),
        'protocol_type': np.random.choice(['TCP', 'UDP', 'ICMP'], n_normal, p=[0.7, 0.25, 0.05]),
        'src_bytes': np.random.lognormal(8, 2, n_normal).astype(int),
        'dst_bytes': np.random.lognormal(8, 2, n_normal).astype(int),
        'packet_count': np.random.poisson(10, n_normal),
        'flag': np.random.choice(['SF', 'S0', 'S1'], n_normal, p=[0.8, 0.15, 0.05]),
        'label': ['normal'] * n_normal
    }
    
    # Generate anomalous traffic data (20% of data)
    n_anomaly = n_samples - n_normal
    
    anomaly_data = {
        'duration': np.random.exponential(5.0, n_anomaly),  # Longer durations
        'protocol_type': np.random.choice(['TCP', 'UDP', 'ICMP'], n_anomaly, p=[0.4, 0.5, 0.1]),
        'src_bytes': np.random.lognormal(12, 3, n_anomaly).astype(int),  # More bytes
        'dst_bytes': np.random.lognormal(6, 3, n_anomaly).astype(int),   # Fewer response bytes
        'packet_count': np.random.poisson(50, n_anomaly),  # More packets
        'flag': np.random.choice(['REJ', 'S0', 'S2', 'S3'], n_anomaly, p=[0.4, 0.3, 0.2, 0.1]),
        'label': ['anomaly'] * n_anomaly
    }
    
    # Combine data
    all_data = {}
    for key in normal_data.keys():
        all_data[key] = np.concatenate([normal_data[key], anomaly_data[key]])
    
    # Create DataFrame
    df = pd.DataFrame(all_data)
    
    # Shuffle the data
    df = df.sample(frac=1).reset_index(drop=True)
    
    # Ensure data directory exists
    os.makedirs('data', exist_ok=True)
    
    # Save to CSV
    df.to_csv('data/dataset.csv', index=False)
    
    print(f"Sample dataset created with {n_samples} samples")
    print(f"Normal samples: {n_normal}")
    print(f"Anomaly samples: {n_anomaly}")
    print("Dataset saved to: data/dataset.csv")
    print("\nDataset preview:")
    print(df.head())
    print("\nLabel distribution:")
    print(df['label'].value_counts())

if __name__ == "__main__":
    create_sample_dataset()
