import sys
import io
import os
import joblib
import warnings
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.preprocessing import StandardScaler, label_binarize
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import (
    classification_report,
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    roc_curve,
    auc,
    precision_recall_curve,
    average_precision_score
)
from sklearn.ensemble import VotingClassifier
from itertools import cycle

# Fix for Windows UnicodeEncodeError when printing emojis
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

warnings.filterwarnings('ignore')

# Paths
DATA_PATH = 'data/clean_anomaly_dataset.csv'
MODEL_PATH = 'model/anomaly_ensemble.pkl'
SCALER_PATH = 'model/scaler.pkl'

# Required columns
REQUIRED_COLUMNS = ['duration', 'protocol_type', 'src_bytes', 'dst_bytes', 'ttl', 'flag', 'label']

# -------------------------------------------------------------------
# Utility Functions
# -------------------------------------------------------------------
def load_data():
    if not os.path.exists(DATA_PATH):
        raise FileNotFoundError(f"❌ Dataset not found at: {DATA_PATH}")

    df = pd.read_csv(DATA_PATH)

    # Ensure required columns exist
    for col in REQUIRED_COLUMNS:
        if col not in df.columns:
            raise ValueError(f"❌ Missing required column: {col}")

    # Encode 'protocol_type'
    df['protocol_type'] = df['protocol_type'].map({'TCP': 1, 'UDP': 2, 'ICMP': 3}).fillna(0)

    # Encode 'flag'
    df['flag'] = df['flag'].apply(lambda x: hash(x) % 10 if pd.notnull(x) else 0)

    return df

def evaluate_model(name, model, X_test, y_test, class_labels, results_dict, fold=None):
    """Evaluate model and store metrics"""
    y_pred = model.predict(X_test)

    acc = accuracy_score(y_test, y_pred)
    prec = precision_score(y_test, y_pred, average='weighted', zero_division=0)
    rec = recall_score(y_test, y_pred, average='weighted', zero_division=0)
    f1 = f1_score(y_test, y_pred, average='weighted', zero_division=0)

    fold_info = f" (Fold {fold})" if fold else ""
    print(f"\n✅ {name}{fold_info} Accuracy: {acc:.4f}")
    class_labels_str = [str(lbl) for lbl in class_labels]
    print(classification_report(y_test, y_pred, target_names=class_labels_str))

    key = f"{name}{fold_info}" if fold else name
    results_dict[key] = {"Accuracy": acc, "Precision": prec, "Recall": rec, "F1-score": f1}

    # Confusion matrix
    cm = confusion_matrix(y_test, y_pred)
    plt.figure(figsize=(6, 5))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
                xticklabels=class_labels_str, yticklabels=class_labels_str)
    plt.title(f"{name}{fold_info} - Confusion Matrix")
    plt.ylabel('True Label')
    plt.xlabel('Predicted Label')
    plt.tight_layout()
    plt.savefig(f"results/{name}{fold_info}_confusion_matrix.png")
    plt.close()

# -------------------------------------------------------------------
# Training
# -------------------------------------------------------------------
def train_models(X, y, class_labels):
    from xgboost import XGBClassifier
    from lightgbm import LGBMClassifier
    from catboost import CatBoostClassifier

    print("🚀 Training classifiers with 5-Fold Cross Validation...")

    # Standardize features
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

    # Define models
    models = {
        "XGBoost": XGBClassifier(
            n_estimators=200, learning_rate=0.1, max_depth=6,
            random_state=42, use_label_encoder=False, eval_metric='logloss'
        ),
        "LightGBM": LGBMClassifier(
            n_estimators=200, learning_rate=0.1, max_depth=-1,
            random_state=42, n_jobs=-1
        ),
        "CatBoost": CatBoostClassifier(
            iterations=200, learning_rate=0.1, depth=6,
            random_state=42, verbose=0
        )
    }

    results = {}
    os.makedirs("results", exist_ok=True)

    # Cross-validation loop
    for fold, (train_idx, test_idx) in enumerate(skf.split(X_scaled, y), 1):
        X_train, X_test = X_scaled[train_idx], X_scaled[test_idx]
        y_train, y_test = y.iloc[train_idx], y.iloc[test_idx]

        trained_models = {}
        for name, model in models.items():
            print(f"\n🧠 Training {name} (Fold {fold})...")
            model.fit(X_train, y_train)
            evaluate_model(name, model, X_test, y_test, class_labels, results, fold=fold)
            trained_models[name] = model

        # Ensemble for this fold
        ensemble = VotingClassifier(
            estimators=[(n, m) for n, m in trained_models.items()],
            voting='soft'
        )
        ensemble.fit(X_train, y_train)
        evaluate_model("Ensemble", ensemble, X_test, y_test, class_labels, results, fold=fold)

    # After CV, retrain final ensemble on all data
    print("\n🤝 Training final Ensemble on full dataset...")
    final_models = {
        "XGBoost": XGBClassifier(
            n_estimators=200, learning_rate=0.1, max_depth=6,
            random_state=42, use_label_encoder=False, eval_metric='logloss'
        ),
        "LightGBM": LGBMClassifier(
            n_estimators=200, learning_rate=0.1, max_depth=-1,
            random_state=42, n_jobs=-1
        ),
        "CatBoost": CatBoostClassifier(
            iterations=200, learning_rate=0.1, depth=6,
            random_state=42, verbose=0
        )
    }
    for name, model in final_models.items():
        model.fit(X_scaled, y)

    final_ensemble = VotingClassifier(
        estimators=[(n, m) for n, m in final_models.items()],
        voting='soft'
    )
    final_ensemble.fit(X_scaled, y)

    # --- Final evaluation with ROC + PR curves ---
    if hasattr(final_ensemble, "predict_proba"):
        y_score = final_ensemble.predict_proba(X_scaled)

        if len(class_labels) == 2:  # ✅ Binary classification
            fpr, tpr, _ = roc_curve(y, y_score[:, 1])
            roc_auc = auc(fpr, tpr)

            plt.figure()
            plt.plot(fpr, tpr, color="blue", lw=2,
                     label=f"ROC curve (AUC = {roc_auc:.2f})")
            plt.plot([0, 1], [0, 1], "k--", lw=2)
            plt.xlabel("False Positive Rate")
            plt.ylabel("True Positive Rate")
            plt.title("Final Ensemble - ROC Curve")
            plt.legend(loc="lower right")
            plt.tight_layout()
            plt.savefig("results/Ensemble_ROC_Curve.png")
            plt.close()

            precision, recall, _ = precision_recall_curve(y, y_score[:, 1])
            pr_auc = average_precision_score(y, y_score[:, 1])

            plt.figure()
            plt.plot(recall, precision, color="green", lw=2,
                     label=f"PR curve (AP = {pr_auc:.2f})")
            plt.xlabel("Recall")
            plt.ylabel("Precision")
            plt.title("Final Ensemble - Precision-Recall Curve")
            plt.legend(loc="lower left")
            plt.tight_layout()
            plt.savefig("results/Ensemble_PR_Curve.png")
            plt.close()

        else:  # ✅ Multi-class classification
            y_bin = label_binarize(y, classes=class_labels)
            fpr, tpr, roc_auc = {}, {}, {}
            for i in range(len(class_labels)):
                fpr[i], tpr[i], _ = roc_curve(y_bin[:, i], y_score[:, i])
                roc_auc[i] = auc(fpr[i], tpr[i])

            plt.figure()
            colors = cycle(['blue', 'red', 'green', 'purple', 'orange'])
            for i, color in zip(range(len(class_labels)), colors):
                plt.plot(fpr[i], tpr[i], color=color, lw=2,
                         label=f"Class {class_labels[i]} (AUC = {roc_auc[i]:.2f})")

            plt.plot([0, 1], [0, 1], 'k--', lw=2)
            plt.xlabel('False Positive Rate')
            plt.ylabel('True Positive Rate')
            plt.title("Final Ensemble - ROC Curve")
            plt.legend(loc="lower right")
            plt.tight_layout()
            plt.savefig("results/Ensemble_ROC_Curve.png")
            plt.close()

            precision, recall, pr_auc = {}, {}, {}
            for i in range(len(class_labels)):
                precision[i], recall[i], _ = precision_recall_curve(y_bin[:, i], y_score[:, i])
                pr_auc[i] = average_precision_score(y_bin[:, i], y_score[:, i])

            plt.figure()
            colors = cycle(['blue', 'red', 'green', 'purple', 'orange'])
            for i, color in zip(range(len(class_labels)), colors):
                plt.plot(recall[i], precision[i], color=color, lw=2,
                         label=f"Class {class_labels[i]} (AP = {pr_auc[i]:.2f})")

            plt.xlabel('Recall')
            plt.ylabel('Precision')
            plt.title("Final Ensemble - Precision-Recall Curve")
            plt.legend(loc="lower left")
            plt.tight_layout()
            plt.savefig("results/Ensemble_PR_Curve.png")
            plt.close()

    return final_ensemble, scaler, results

# -------------------------------------------------------------------
# Main
# -------------------------------------------------------------------
def main():
    print("📥 Loading dataset...")
    df = load_data()

    X = df.drop('label', axis=1)
    y = df['label']

    class_labels = sorted(y.unique().tolist())

    print("📊 Feature sample:")
    print(X.head())

    print("🧠 Starting training with XGBoost, LightGBM, CatBoost...")
    model, scaler, results = train_models(X, y, class_labels)

    os.makedirs('model', exist_ok=True)
    joblib.dump(model, MODEL_PATH)
    joblib.dump(scaler, SCALER_PATH)

    results_df = pd.DataFrame(results).T
    results_df.to_csv("results/metrics_summary.csv")
    print("\n📈 Metrics Summary:")
    print(results_df)

    print("\n✅ Training complete!")
    print(f"🔒 Ensemble model saved to: {MODEL_PATH}")
    print(f"📐 Scaler saved to: {SCALER_PATH}")
    print("📊 Confusion matrices, ROC and PR curves saved to: results/")

if __name__ == '__main__':
    main()
