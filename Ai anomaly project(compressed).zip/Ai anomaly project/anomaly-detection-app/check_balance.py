import os
import pandas as pd

# Path to your dataset
DATA_PATH = 'data/clean_anomaly_dataset.csv'

# Check if dataset exists
if not os.path.exists(DATA_PATH):
    print(f"❌ Dataset not found at: {DATA_PATH}")
    exit()

# Load dataset
df = pd.read_csv(DATA_PATH)

# Ensure label column exists
if 'label' not in df.columns:
    print("❌ 'label' column not found in dataset!")
    print("Available columns:", df.columns.tolist())
    exit()

# Count class distribution
class_counts = df['label'].value_counts()
total_samples = len(df)

print("\n📊 Dataset Class Distribution:")
for cls, count in class_counts.items():
    percent = (count / total_samples) * 100
    print(f" - {cls}: {count} samples ({percent:.2f}%)")

print(f"\n✅ Total samples: {total_samples}")
