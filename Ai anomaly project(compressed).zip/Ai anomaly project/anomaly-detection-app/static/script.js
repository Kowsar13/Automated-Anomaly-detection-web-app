// Global variables
let isTraining = false;
let isPredicting = false;

// Check system status
async function checkSystemStatus() {
    try {
        const response = await fetch('/model-status');
        const data = await response.json();

        const modelStatus = document.getElementById('model-status');
        const datasetStatus = document.getElementById('dataset-status');

        if (modelStatus) {
            modelStatus.textContent = data.model_trained ? 'Trained' : 'Not Trained';
            modelStatus.className = `status-value ${data.model_trained ? 'status-success' : 'status-warning'}`;
        }

        if (datasetStatus) {
            datasetStatus.textContent = data.datasets_available ? 'Available' : 'Not Found';
            datasetStatus.className = `status-value ${data.datasets_available ? 'status-success' : 'status-error'}`;
        }
    } catch (error) {
        console.error('Error checking system status:', error);
    }
}

// Train model function
async function trainModel() {
    if (isTraining) return;

    isTraining = true;
    const trainBtn = document.getElementById('train-btn');
    const trainText = document.getElementById('train-text');
    const trainSpinner = document.getElementById('train-spinner');
    const resultDiv = document.getElementById('train-result');
    const resultContent = document.getElementById('result-content');

    trainBtn.disabled = true;
    trainText.style.display = 'none';
    trainSpinner.style.display = 'inline-block';
    resultDiv.style.display = 'none';

    try {
        const response = await fetch('/train', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
        });

        const data = await response.json();
        resultDiv.style.display = 'block';
        resultDiv.className = `result-section ${data.success ? 'result-success' : 'result-error'}`;

        if (data.success) {
            resultContent.innerHTML = `
                <h3>✅ Training Successful!</h3>
                <p>${data.message}</p>
                ${data.details ? `<pre style="background: #f8fafc; padding: 1rem; border-radius: 5px; margin-top: 1rem; overflow-x: auto;">${data.details}</pre>` : ''}
            `;
        } else {
            resultContent.innerHTML = `
                <h3>❌ Training Failed</h3>
                <p>${data.message}</p>
            `;
        }

        setTimeout(checkSystemStatus, 1000);

    } catch (error) {
        resultDiv.style.display = 'block';
        resultDiv.className = 'result-section result-error';
        resultContent.innerHTML = `
            <h3>❌ Error</h3>
            <p>Failed to communicate with server: ${error.message}</p>
        `;
    } finally {
        isTraining = false;
        trainBtn.disabled = false;
        trainText.style.display = 'inline';
        trainSpinner.style.display = 'none';
    }
}

// Fill example data (updated TTL instead of packet count)
function fillExampleData(type) {
    const form = document.getElementById('predict-form');
    if (!form) return;

    if (type === 'normal') {
        form.duration.value = '0.121';
        form.protocol_type.value = 'TCP';
        form.src_bytes.value = '258';
        form.dst_bytes.value = '172';
        form.ttl.value = '252';
        form.flag.value = 'SF';
    } else if (type === 'suspicious') {
        form.duration.value = '1.623';
        form.protocol_type.value = 'UDP';
        form.src_bytes.value = '364';
        form.dst_bytes.value = '13186';
        form.ttl.value = '62';
        form.flag.value = 'REJ';
    }
}

// Handle prediction form submission
document.addEventListener('DOMContentLoaded', function () {
    const predictForm = document.getElementById('predict-form');
    if (predictForm) {
        predictForm.addEventListener('submit', async function (e) {
            e.preventDefault();
            if (isPredicting) return;

            isPredicting = true;
            const predictText = document.getElementById('predict-text');
            const predictSpinner = document.getElementById('predict-spinner');
            const resultDiv = document.getElementById('prediction-result');
            const resultContent = document.getElementById('prediction-content');
            const submitBtn = predictForm.querySelector('button[type="submit"]');

            submitBtn.disabled = true;
            predictText.style.display = 'none';
            predictSpinner.style.display = 'inline-block';
            resultDiv.style.display = 'none';

            try {
                const formData = new FormData(predictForm);
                const data = {};
                for (let [key, value] of formData.entries()) {
                    data[key] = value;
                }

                const response = await fetch('/predict', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(data)
                });

                const result = await response.json();

                resultDiv.style.display = 'block';
                resultDiv.className = `result-section ${result.success ? 'result-success' : 'result-error'}`;

                if (result.success) {
                    const isAnomaly = result.prediction === 'Anomalies Traffic'; // ✅ fixed condition
                    const icon = isAnomaly ? '🚨' : '✅';
                    const statusClass = isAnomaly ? 'status-error' : 'status-success';

                    resultContent.innerHTML = `
                        <h3>${icon} Prediction Result</h3>
                        <div style="margin: 1rem 0;">
                            <span class="status-label">Prediction:</span>
                            <span class="status-value ${statusClass}">${result.prediction}</span>
                        </div>
                        ${result.confidence !== undefined ? `
                            <div style="margin: 1rem 0;">
                                <span class="status-label">Confidence Score:</span>
                                <span class="status-value">${result.confidence.toFixed(4)}</span>
                            </div>
                        ` : ''}
                        <p style="margin-top: 1rem; color: #666;">
                            ${isAnomaly ?
                                'This network traffic pattern appears to be anomalous and may require further investigation.' :
                                'This network traffic pattern appears to be normal.'
                            }
                        </p>
                    `;
                } else {
                    resultContent.innerHTML = `
                        <h3>❌ Prediction Failed</h3>
                        <p>${result.message}</p>
                    `;
                }

            } catch (error) {
                resultDiv.style.display = 'block';
                resultDiv.className = 'result-section result-error';
                resultContent.innerHTML = `
                    <h3>❌ Error</h3>
                    <p>Failed to communicate with server: ${error.message}</p>
                `;
            } finally {
                isPredicting = false;
                submitBtn.disabled = false;
                predictText.style.display = 'inline';
                predictSpinner.style.display = 'none';
            }
        });
    }
});

// Initialize page
document.addEventListener('DOMContentLoaded', function () {
    checkSystemStatus();
    setInterval(checkSystemStatus, 30000); // Refresh every 30s
});
