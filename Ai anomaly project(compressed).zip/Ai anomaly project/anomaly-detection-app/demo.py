import pandas as pd
import os

# File paths
train_path = 'data/UNSW_NB15_training-set.csv'
test_path = 'data/UNSW_NB15_testing-set.csv'
output_path = 'data/clean_anomaly_dataset.csv'

# Selected columns
selected_columns = ['dur', 'proto', 'sbytes', 'dbytes', 'sttl', 'state', 'label']

# Mapping for proto
proto_map = {'TCP': 1, 'UDP': 2, 'ICMP': 3}

# Ensure dataset files exist
if not os.path.exists(train_path) or not os.path.exists(test_path):
    print("❌ Training or testing dataset not found in 'data/' folder.")
    exit()

# Load and merge
df_train = pd.read_csv(train_path)
df_test = pd.read_csv(test_path)
df = pd.concat([df_train, df_test], ignore_index=True)

# Drop rows with missing required columns
df = df.dropna(subset=selected_columns)

# Keep only selected columns
df = df[selected_columns].copy()

# Encode proto
df['proto'] = df['proto'].map(proto_map).fillna(0)

# Encode state using simple hashing
df['state'] = df['state'].apply(lambda x: hash(x) % 10 if pd.notnull(x) else 0)

# Convert label: 0 = Normal, 1 = Anomaly
df['label'] = df['label'].apply(lambda x: 0 if x == 0 else 1)

# Rename columns to match frontend/backend naming
df.rename(columns={
    'dur': 'duration',
    'proto': 'protocol_type',
    'sbytes': 'src_bytes',
    'dbytes': 'dst_bytes',
    'sttl': 'ttl',
    'state': 'flag'
}, inplace=True)

# Save clean dataset
df.to_csv(output_path, index=False)
print(f"✅ Clean dataset saved to: {output_path}")
print("🔍 Preview:")
print(df.head())
