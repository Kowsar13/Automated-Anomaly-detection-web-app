from flask import Flask, render_template, request, jsonify, redirect, url_for, flash, send_file
from flask_cors import CORS
import joblib
import numpy as np
import os
import subprocess
import sys
import threading
import time
import sqlite3
from datetime import datetime, timedelta
import csv

from scapy.all import sniff, IP, TCP, UDP, ICMP
from scapy.layers.dns import DNS, DNSRR
from collections import deque

import google.generativeai as genai   # Gemini
import sqlite3
from flask_login import login_required, current_user



# ------------------------------
# Auth imports
# ------------------------------
from flask_login import (
    LoginManager, UserMixin, login_user,
    login_required, logout_user, current_user
)
from werkzeug.security import generate_password_hash, check_password_hash

# Optional (for dashboard stats)
import pandas as pd

# ------------------------------
# App Setup
# ------------------------------
app = Flask(__name__)
app.secret_key = "replace-with-a-strong-secret"  # needed for sessions
CORS(app)

# ------------------------------
# Gemini Setup (kept as you had)
# ------------------------------
genai.configure(api_key="AIzaSyBeQVrvufaAFvpJtolOI6Y1bonFRWzzc2c")

# Paths
MODEL_PATH = 'model/anomaly_ensemble.pkl'
SCALER_PATH = 'model/scaler.pkl'
DATA_PATH = 'data/clean_anomaly_dataset.csv'
USER_DB = 'users.db'

# Ensure directories exist
os.makedirs('model', exist_ok=True)
os.makedirs('data', exist_ok=True)
os.makedirs('templates', exist_ok=True)
os.makedirs('static', exist_ok=True)
os.makedirs('results', exist_ok=True)

# ------------------------------
# User Auth Setup
# ------------------------------
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

def get_db():
    conn = sqlite3.connect(USER_DB)
    conn.row_factory = sqlite3.Row
    return conn

def init_user_db():
    conn = get_db()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS users(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT,
            password_hash TEXT NOT NULL,
            phone TEXT,
            academic_info TEXT,
            address TEXT,
            gender TEXT,
            age INTEGER,
            created_at TEXT NOT NULL
        )
    """)
    conn.commit()
    conn.close()


class User(UserMixin):
    def __init__(self, id_, username, email, password_hash):
        self.id = str(id_)
        self.username = username
        self.email = email
        self.password_hash = password_hash

def find_user_by_id(user_id):
    conn = get_db()
    cur = conn.execute("SELECT * FROM users WHERE id=?", (user_id,))
    row = cur.fetchone()
    conn.close()
    if row:
        return User(row['id'], row['username'], row['email'], row['password_hash'])
    return None

def find_user_by_username(username):
    conn = get_db()
    cur = conn.execute("SELECT * FROM users WHERE username=?", (username,))
    row = cur.fetchone()
    conn.close()
    if row:
        return User(row['id'], row['username'], row['email'], row['password_hash'])
    return None

@login_manager.user_loader
def load_user(user_id):
    return find_user_by_id(user_id)

@login_manager.unauthorized_handler
def unauthorized():
    if request.is_json:
        return jsonify({"success": False, "message": "Authentication required"}), 401
    return redirect(url_for('login'))

@app.route('/admin')
def admin_page():
    return render_template('admin.html')


# ------------------------------
# Real-time Packet Capture
# ------------------------------
latest_packet = {}
packet_buffer = deque(maxlen=10)        # recent packets for live log
traffic_window = deque(maxlen=120)     # last 2 minutes timestamps for chart
dns_map = {}
start_time = time.time()

def map_flag_to_category(raw_flag: str) -> str:
    if raw_flag in ["S", "SA"]:
        return "S0"   # Connection attempt
    elif raw_flag in ["PA", "A"]:
        return "S1"   # Established
    elif raw_flag in ["F", "FA"]:
        return "S2"   # Closed
    elif raw_flag in ["R", "RA"]:
        return "S3"   # Reset
    elif raw_flag == "REJ":
        return "REJ"  # Explicit reject
    else:
        return "SF"   # Normal

def process_packet(packet):
    global latest_packet, dns_map
    duration = round(time.time() - start_time, 5)
    proto, src_bytes, dst_bytes, ttl = None, 0, 0, None
    raw_flag, mapped_flag = "SF", "SF"
    src_ip, dst_ip, dst_host = None, None, None

    # learn DNS answers for nicer host display
    if packet.haslayer(DNS) and packet.getlayer(DNS).ancount > 0:
        for i in range(packet[DNS].ancount):
            rr = packet[DNS].an[i]
            if isinstance(rr, DNSRR):
                domain = rr.rrname.decode("utf-8").strip(".")
                ip = rr.rdata
                dns_map[str(ip)] = domain

    if IP in packet:
        src_ip = packet[IP].src
        dst_ip = packet[IP].dst
        ttl = packet[IP].ttl
        dst_host = dns_map.get(dst_ip, dst_ip)

        if TCP in packet:
            proto = "TCP"
            src_bytes = len(packet[TCP].payload)
            dst_bytes = packet[IP].len
            raw_flag = str(packet[TCP].flags)
            mapped_flag = map_flag_to_category(raw_flag)
        elif UDP in packet:
            proto = "UDP"
            src_bytes = len(packet[UDP].payload)
            dst_bytes = packet[IP].len
        elif ICMP in packet:
            proto = "ICMP"
            dst_bytes = packet[IP].len

        latest_packet = {
            "duration": duration,
            "protocol_type": proto,
            "src_bytes": src_bytes,
            "dst_bytes": dst_bytes,
            "ttl": ttl,
            "raw_flag": raw_flag,
            "flag": mapped_flag,
            "src_ip": src_ip,
            "dst_ip": dst_ip,
            "dst_host": dst_host
        }

        packet_buffer.append(latest_packet)
        traffic_window.append(int(time.time()))

def start_sniffer():
    sniff(prn=process_packet, store=False)

threading.Thread(target=start_sniffer, daemon=True).start()

# ------------------------------
# Attack Signature Detection
# ------------------------------
def classify_attack(features, proto, flag, ttl):
    """
    Heuristic mapping for anomalies (original + extra logics).
    features = [duration, proto_num, src_bytes, dst_bytes, ttl, flag_hash]
    """

    duration, proto_num, src_bytes, dst_bytes, ttl_val, _ = features

    # --- Original ones you had ---
    if proto == "TCP" and flag == "S0":
        return "Port Scan"

    if proto == "UDP" and dst_bytes > 100000:
        return "DoS Attack"

    if ttl_val is not None and ttl_val < 5:
        return "Probe"

    # 4. SYN Flood: many SYNs but no data
    if proto == "TCP" and flag == "S1" and src_bytes == 0:
        return "SYN Flood"

    # 5. ICMP Flood: huge ICMP packets very quickly
    if proto == "ICMP" and dst_bytes > 1000 and duration < 0.01:
        return "ICMP Flood"

    # 6. Data Exfiltration: very large uploads
    if src_bytes > 1e6:
        return "Exfiltration"

    # 7. Amplification / Large Download
    if dst_bytes > 1e7:
        return "Amplification Attack"

    return "Unknown Anomaly"




# ------------------------------
# Anomaly Logging (per-user)
# ------------------------------
def anomaly_csv_path(user_id: str):
    return os.path.join("results", f"anomalies_user_{user_id}.csv")

def append_anomaly_log(user_id: str, row: dict):
    """Append a single anomaly record to the user's CSV (create with header if missing)."""
    path = anomaly_csv_path(user_id)
    file_exists = os.path.exists(path)
    fieldnames = [
        "timestamp", "user_id", "username",
        "duration", "protocol_type", "src_bytes", "dst_bytes", "ttl", "flag",
        "src_ip", "dst_ip", "dst_host",
        "result", "attack_type", "confidence"
    ]
    with open(path, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        if not file_exists:
            writer.writeheader()
        writer.writerow(row)

# ------------------------------
# Routes (Pages)
# ------------------------------
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/faq')
def faq_page():
    return render_template('faq.html')

# ---- Auth Routes ----
@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('home'))
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '').strip()
        if not username or not password:
            flash("Username and password required", "error")
            return redirect(url_for('register'))
        if find_user_by_username(username):
            flash("Username already exists", "error")
            return redirect(url_for('register'))
        pw_hash = generate_password_hash(password)
        conn = get_db()
        conn.execute("INSERT INTO users(username,email,password_hash,created_at) VALUES(?,?,?,?)",
                     (username, email, pw_hash, datetime.utcnow().isoformat()))
        conn.commit()
        conn.close()
        flash("Registration successful. Please login.", "success")
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('home'))
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '').strip()
        user = find_user_by_username(username)
        if not user or not check_password_hash(user.password_hash, password):
            flash("Invalid credentials", "error")
            return redirect(url_for('login'))
        login_user(user, remember=True)
        return redirect(url_for('home'))
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('home'))

@app.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    conn = sqlite3.connect("users.db")
    c = conn.cursor()

    if request.method == 'POST':
        phone = request.form.get('phone')
        academic_info = request.form.get('academic_info')
        address = request.form.get('address')
        gender = request.form.get('gender')
        age = request.form.get('age')

        c.execute("""
            UPDATE users
            SET phone = ?, academic_info = ?, address = ?, gender = ?, age = ?
            WHERE username = ?
        """, (phone, academic_info, address, gender, age, current_user.id))
        conn.commit()

    c.execute("SELECT username, email, phone, academic_info, address, gender, age FROM users WHERE id = ?", (current_user.id,))
    user = c.fetchone()
    conn.close()

    return render_template('profile.html', user=user)



# ---- Protected Pages ----
@app.route('/train')
@login_required
def train_page():
    return render_template('train.html')

@app.route('/predict')
@login_required
def predict_page():
    return render_template('predict.html')

# NEW: Dashboard page (anomaly counters + download button)
@app.route('/dashboard')
@login_required
def dashboard_page():
    return render_template('dashboard.html')

# ------------------------------
# API Endpoints (Protected)
# ------------------------------
# Train endpoint
@app.route('/train', methods=['POST'])
@login_required
def train_model():
    try:
        if not os.path.exists(DATA_PATH):
            return jsonify({'success': False,'message':'Dataset not found. Please make sure clean_anomaly_dataset.csv exists in the data/ folder.'})
        result = subprocess.run([sys.executable, 'train_model.py'],capture_output=True,text=True)
        if result.returncode == 0:
            return jsonify({'success': True,'message':'✅ Model trained successfully!','details': result.stdout})
        else:
            return jsonify({'success': False,'message': f'❌ Training failed:\n{result.stderr}'})
    except Exception as e:
        return jsonify({'success': False,'message': f'Training error: {str(e)}'})

# Predict endpoint
@app.route('/predict', methods=['POST'])
@login_required
def predict_anomaly():
    try:
        if not os.path.exists(MODEL_PATH) or not os.path.exists(SCALER_PATH):
            return jsonify({'success': False,'message':'Model or scaler not found. Please train the model first.'})

        model = joblib.load(MODEL_PATH)
        scaler = joblib.load(SCALER_PATH)

        data = request.json

        features = [
            float(data.get('duration', 0)),
            1 if data.get('protocol_type') == 'TCP' else (2 if data.get('protocol_type') == 'UDP' else 3),
            float(data.get('src_bytes', 0)),
            float(data.get('dst_bytes', 0)),
            float(data.get('ttl', 0)),
            hash(data.get('flag', 'SF')) % 10
        ]

        features_array = np.array(features).reshape(1, -1)
        features_scaled = scaler.transform(features_array)

        prediction = model.predict(features_scaled)[0]

        if prediction == 0:
            result = "Normal Traffic"
            attack_type = None
        else:
            attack_type = classify_attack(features, data.get('protocol_type'), data.get('flag'), float(data.get('ttl', 0)))
            result = f"Anomalous Traffic ({attack_type})"

        confidence = None
        if hasattr(model, 'predict_proba'):
            confidence = float(np.max(model.predict_proba(features_scaled)))
        elif hasattr(model, 'decision_function'):
            confidence = float(model.decision_function(features_scaled)[0])

        # ------------------------------
        # Gemini Explanation (unchanged)
        # ------------------------------
        explanation = None
        try:
            model_gemini = genai.GenerativeModel("gemini-1.5-flash")
            prompt = f"Explain in simple terms why the network traffic was classified as: {result}. " \
                     f"Features: duration={features[0]}, protocol={data.get('protocol_type')}, " \
                     f"src_bytes={features[2]}, dst_bytes={features[3]}, ttl={features[4]}, flag={data.get('flag')}."
            response = model_gemini.generate_content(prompt)
            explanation = response.text
        except Exception as ge:
            explanation = f"Gemini explanation unavailable: {str(ge)}"

        # ------------------------------
        # Log anomaly ONLY (per user)
        # ------------------------------
        if prediction != 0:
            try:
                row = {
                    "timestamp": datetime.utcnow().isoformat(),
                    "user_id": current_user.id,
                    "username": current_user.username,
                    "duration": data.get('duration'),
                    "protocol_type": data.get('protocol_type'),
                    "src_bytes": data.get('src_bytes'),
                    "dst_bytes": data.get('dst_bytes'),
                    "ttl": data.get('ttl'),
                    "flag": data.get('flag'),
                    "src_ip": data.get('src_ip'),           # may be None for manual input
                    "dst_ip": data.get('dst_ip'),
                    "dst_host": data.get('dst_host'),
                    "result": result,
                    "attack_type": attack_type,
                    "confidence": confidence
                }
                append_anomaly_log(current_user.id, row)
            except Exception as le:
                # don't block prediction response if logging fails
                print("Anomaly logging error:", le)

        return jsonify({
            'success': True,
            'prediction': result,
            'confidence': confidence,
            'explanation': explanation
        })

    except Exception as e:
        return jsonify({'success': False,'message': f'Prediction error: {str(e)}'})

# Protected status (keep or make public if you want)
@app.route('/model-status')
@login_required
def model_status():
    model_exists = os.path.exists(MODEL_PATH)
    dataset_exists = os.path.exists(DATA_PATH)
    return jsonify({
        'model_trained': model_exists,
        'datasets_available': dataset_exists,
        'model_path': MODEL_PATH if model_exists else None
    })

@app.route('/latest-packet')
@login_required
def get_latest_packet():
    if latest_packet:
        return jsonify({"success": True, "packet": latest_packet})
    return jsonify({"success": False, "message": "No packet captured yet."})

@app.route('/recent-packets')
@login_required
def get_recent_packets():
    return jsonify({"success": True, "packets": list(packet_buffer)})

@app.route('/traffic-volume')
@login_required
def get_traffic_volume():
    counts = {}
    for t in traffic_window:
        counts[t] = counts.get(t, 0) + 1
    sorted_counts = dict(sorted(counts.items()))
    return jsonify({"success": True, "volume": sorted_counts})

# ------------------------------
# NEW: Anomaly Dashboard Data + Download
# ------------------------------
@app.route('/anomalies/data')
@login_required
def anomalies_data():
    """Return counters & timeseries for the current user's anomalies."""
    path = anomaly_csv_path(current_user.id)

    if not os.path.exists(path):
        return jsonify({
            "success": True,
            "totals": {"total": 0, "last24h": 0, "unique_sources": 0},
            "top_types": {},
            "top_hosts": {},
            "timeseries": {"labels": [], "counts": []},
            "recent": []
        })

    try:
        import pandas as pd
        df = pd.read_csv(path)

        if df.empty:
            return jsonify({
                "success": True,
                "totals": {"total": 0, "last24h": 0, "unique_sources": 0},
                "top_types": {},
                "top_hosts": {},
                "timeseries": {"labels": [], "counts": []},
                "recent": []
            })

        # Ensure required columns exist
        for col in ["timestamp", "attack_type", "src_ip", "dst_ip", "dst_host", "confidence"]:
            if col not in df.columns:
                df[col] = None

        # Parse timestamps safely
        df['ts'] = pd.to_datetime(df['timestamp'], errors='coerce')
        df = df.dropna(subset=['ts'])

        # Normalize tz to avoid tz-naive vs tz-aware comparison errors
        df['ts'] = df['ts'].dt.tz_localize(None)
        last_24_cut = (pd.Timestamp.utcnow() - pd.Timedelta(hours=24)).tz_localize(None)

        # Totals
        total = len(df)
        last24h = int((df['ts'] >= last_24_cut).sum())
        unique_sources = int(df['src_ip'].dropna().nunique())

        # Top attack types
        top_types = df['attack_type'].fillna("Unknown").value_counts().head(5).to_dict()

        # Top target hosts (prefer dst_host, fallback dst_ip)
        host_series = df['dst_host'].fillna(df['dst_ip']).fillna("Unknown")
        top_hosts = host_series.value_counts().head(5).to_dict()

        # Timeseries (per minute counts)
        per_min = df.set_index('ts').resample('1T').size()
        labels = [t.isoformat() for t in per_min.index.to_pydatetime()]
        counts = per_min.values.tolist()

        # Recent 10 anomalies
        recent_df = df.sort_values('ts', ascending=False).head(10)
        recent = []
        for _, r in recent_df.iterrows():
            recent.append({
                "timestamp": r['timestamp'],
                "attack_type": r['attack_type'] if pd.notnull(r['attack_type']) else "Unknown",
                "src_ip": r['src_ip'] if pd.notnull(r['src_ip']) else None,
                "dst_host": r['dst_host'] if pd.notnull(r['dst_host']) else (r['dst_ip'] if pd.notnull(r['dst_ip']) else None),
                "confidence": float(r['confidence']) if pd.notnull(r['confidence']) else None
            })

        return jsonify({
            "success": True,
            "totals": {"total": int(total), "last24h": int(last24h), "unique_sources": int(unique_sources)},
            "top_types": top_types,
            "top_hosts": top_hosts,
            "timeseries": {"labels": labels, "counts": counts},
            "recent": recent
        })

    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({"success": False, "message": f"Failed to compute stats: {e}"}), 500


@app.route('/anomalies/download')
@login_required
def anomalies_download():
    """Download the current user's anomaly CSV. Creates a clean empty file if none exists yet."""
    path = anomaly_csv_path(current_user.id)

    # Ensure results folder exists
    os.makedirs("results", exist_ok=True)

    if not os.path.exists(path) or os.path.getsize(path) == 0:
        # Create an empty CSV with header only
        empty_path = os.path.join("results", f"anomalies_user_{current_user.id}_EMPTY.csv")
        fieldnames = [
            "timestamp", "user_id", "username",
            "duration", "protocol_type", "src_bytes", "dst_bytes", "ttl", "flag",
            "src_ip", "dst_ip", "dst_host",
            "result", "attack_type", "confidence"
        ]
        with open(empty_path, "w", newline="", encoding="utf-8") as f:
            import csv
            writer = csv.writer(f)
            writer.writerow(fieldnames)

        return send_file(empty_path, as_attachment=True, download_name="anomalies.csv")

    # Normal case: return the user's anomaly log
    return send_file(path, as_attachment=True, download_name="anomalies.csv")


# ------------------------------
# Run
# ------------------------------
if __name__ == '__main__':
    init_user_db()
    app.run(debug=True, port=5000)
